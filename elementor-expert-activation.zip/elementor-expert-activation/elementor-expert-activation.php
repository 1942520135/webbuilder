<?php
/**
 * Plugin Name:       Elementor Expert Activation
 * Plugin URI:        #
 * Description:       Plugin ini akan membantu Anda mengaktifkan semua fungsi Elementor Pro kecuali koneksi ke perpustakaan Elementor
 * Version:           1.0.2
 * Author:            DIKAT SEO
 * Author URI:        #
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       eea
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

if(!class_exists('EEA_Main_Class')){
    class EEA_Main_Class {

        private static $instance;

        private $need_activate = false;

        private static $site_url = 'http://localhost:8888';

        private static $url_check = 'elementor.com';

        public static function getInstance() {
            if ( self::$instance === null ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            register_activation_hook( __FILE__, [ $this, 'activate' ] );
            register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
            require_once plugin_dir_path( __FILE__ ) . 'class-update.php';
            add_action('plugins_loaded', [ $this, 'init']);
        }

        public function deactivate(){
            $old_key = get_option('eea_old_elementor_pro_license_key');
            $old_data = get_user_option('eea_old_elementor_connect_common_data');
            if(!empty($old_key)){
                update_option('elementor_pro_license_key', $old_key);
                update_option('eea_old_elementor_pro_license_key', '');
            }
            if(!empty($old_data)){
                update_user_option(get_current_user_id(), 'eea_old_elementor_connect_common_data', []);
                update_user_option(get_current_user_id(), 'elementor_connect_common_data', $old_data);
            }
        }

        public function activate(){
            $old_key = get_option('elementor_pro_license_key');
            $old_data = get_user_option('elementor_connect_common_data');
            if(!empty($old_key)){
                update_option('eea_old_elementor_pro_license_key', $old_key);
            }
            if(!empty($old_data)){
                update_user_option(get_current_user_id(), 'eea_old_elementor_connect_common_data', $old_data);
            }
            update_option('elementor_pro_license_key', 'fb351f05958872E193feb37a505a84be');

            $fake_user = new stdClass();
            $fake_user->email = 'andikategar@hotmail.com';

            update_user_option(get_current_user_id(), 'elementor_connect_common_data', [
                'user' => $fake_user
            ]);
        }

        public function init(){
            $this->need_activate = apply_filters('EEA/need_activate', true);
            if($this->need_activate){
                add_filter('http_headers_useragent', [ $this, 'modify_useragent'], 10, 2);
                add_filter('http_request_args', [ $this, 'modify_request_args'], 10, 3);
                add_filter('pre_http_request', [ $this, 'pre_http_request'], 10, 3);
            }
        }

        public function modify_useragent( $useragent, $url ){
            if( strpos( $url, self::$url_check ) !== false){
                $useragent = 'WordPress/' . get_bloginfo( 'version' ) . '; ' . self::$site_url;
            }
            return $useragent;
        }

        public function modify_request_args( $parsed_args, $url ){
            if( strpos( $url, self::$url_check ) !== false){
                if(isset($parsed_args['body']['url'])){
                    $parsed_args['body']['url'] = self::$site_url;
                }
                if(isset($parsed_args['body']['home_url'])){
                    $parsed_args['body']['home_url'] = self::$site_url;
                }
            }
            return $parsed_args;
        }

        public function pre_http_request($response, $parsed_args, $url){
            if( strpos( $url, self::$url_check ) !== false){
                $edd_action = !empty($parsed_args['body']['edd_action']) ? $parsed_args['body']['edd_action'] : '';
                $expires = '2021-10-08 15:55:02';
                if( 'check_license' ===  $edd_action || 'deactivate_license' === $edd_action ){
                    $response = [
                        'response' => [
                            'code' => 200,
                            'message' => 'OK'
                        ],
                        'body' => json_encode([
                            'expires' => $expires,
                            'payment_id' => 1234567,
                            'customer_name' => 'DIKAT SEO',
                            'customer_email' => 'andikategar@hotmail.com',
                            'price_id' => 1,
                            'license_limit' => 1000,
                            'site_count' => 0,
                            'activations_left' => 1000,
                            'success' => true,
                            'license' => 'valid',
                            'item_id' => 9388014,
                            'item_name' => 'Elementor Pro - Expert',
                            'subscriptions' => 'enable',
                            'checksum' => 'checksum'
                        ])
                    ];
                }
                elseif ( 'activate_license' === $edd_action ) {
                    $response = [
                        'response' => [
                            'code' => 200,
                            'message' => 'OK'
                        ],
                        'body' => json_encode([
                            'success' => true,
                            'expires' => $expires,
                            'payment_id' => 1234567,
                            'customer_name' => 'DIKAT SEO',
                            'customer_email' => 'andikategar@hotmail.com',
                            'price_id' => 1,
                            'license' => 'valid',
                            'is_local' => true,
                            'is_wc_customer' => true,
                            'subscriptions' => 'enable'
                        ])
                    ];
                }
            }
            return $response;
        }
    }
}

EEA_Main_Class::getInstance();